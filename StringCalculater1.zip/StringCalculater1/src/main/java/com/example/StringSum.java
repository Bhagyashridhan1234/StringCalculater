package com.example;
import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class StringSum {
    public static int add(String numbers) {
        if (numbers == null || numbers.isEmpty()) {
            return 0;
        }

        String delimiter = ",|\n"; // Default delimiters: comma and newline
        String numbersPart = numbers;

        // Check for custom delimiter
        if (numbers.startsWith("//")) {
            int delimiterEndIndex = numbers.indexOf("\n");
            delimiter = numbers.substring(2, delimiterEndIndex);
            numbersPart = numbers.substring(delimiterEndIndex + 1); // Extract numbers part
        }

        // Split numbers using the delimiters
        String[] numArray = numbersPart.split(delimiter);
        int sum = 0;
        List<Integer> negativeNumbers = new ArrayList<>();

        for (String num : numArray) {
            if (!num.isEmpty()) {
                int parsedNumber = Integer.parseInt(num.trim());
                if (parsedNumber < 0) {
                    negativeNumbers.add(parsedNumber);
                } else {
                    sum += parsedNumber;
                }
            }
        }

        if (!negativeNumbers.isEmpty()) {
            throw new IllegalArgumentException(
                "negative numbers not allowed " + negativeNumbers.toString().replace("[", "<").replace("]", ">")
            );
        }

        return sum;
    }
}
