package com.example;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class StringSumTest {
    @Test
    public void testEmptyString() {
        assertEquals(0, StringSum.sum(""));
    }

    @Test
    public void testSingleNumber() {
        assertEquals(1, StringSum.sum("1"));
    }

    @Test
    public void testTwoNumbers() {
        assertEquals(6, StringSum.sum("1,5"));
    }
    @Test
    public void testNegativeNumber() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            StringSum.sum("1,-3");
        });
        assertEquals("negative numbers not allowed <-3>", exception.getMessage());
    }

    @Test
    public void testMultipleNegativeNumbers() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            StringSum.sum("-1,-3,5");
        });
        assertEquals("negative numbers not allowed <-1,-3>", exception.getMessage());
    }
}
