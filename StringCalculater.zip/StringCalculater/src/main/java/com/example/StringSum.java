package com.example;
import java.util.ArrayList;
import java.util.List;

public class StringSum {
    public static int sum(String numbers) {
        if (numbers == null || numbers.isEmpty()) {
            return 0;
        }

        String[] numArray = numbers.split(",");
        int sum = 0;
        List<Integer> negativeNumbers = new ArrayList<>();

        for (String num : numArray) {
            int parsedNumber = Integer.parseInt(num.trim());
            if (parsedNumber < 0) {
                negativeNumbers.add(parsedNumber);
            } else {
                sum += parsedNumber;
            }
        }

        if (!negativeNumbers.isEmpty()) {
            throw new IllegalArgumentException(
                "negative numbers not allowed " + negativeNumbers.toString().replace("[", "<").replace("]", ">")
            );
        }

        return sum;
    }
}
